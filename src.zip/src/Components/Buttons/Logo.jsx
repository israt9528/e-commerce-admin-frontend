import React from "react";

const Logo = () => {
  return <div className="py-5">E-commerce</div>;
};

export default Logo;
