"use client";
import React from "react";
import ProductDetails from "@/Components/Products/ProductDetails";

export default function page() {
  return (
    <>
      <ProductDetails />;
    </>
  );
}
